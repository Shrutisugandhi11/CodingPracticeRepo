package org.example.basic;

public class Gold {
}
