package org.example.upper.bound;

public class C extends B{
}
