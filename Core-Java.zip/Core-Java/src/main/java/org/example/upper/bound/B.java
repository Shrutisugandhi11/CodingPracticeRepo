package org.example.upper.bound;

public class B extends A{
}
