package org.example.lambda.practice;

public interface Test {

    static  void m1(){
        System.out.println("hello main!!");
    }
}
