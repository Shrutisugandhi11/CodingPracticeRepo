package org.example.lambda.practice;

public class TestChild implements Test {


    public static void main(String[] args) {
        Test.m1();
    }
}
